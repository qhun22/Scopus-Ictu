# Gate D.2 Batch 5 — Summary

**Ngày:** 2026-10-27  
**Phương pháp:** Read-only. Browser mở thực tế. CSV scan. CrossRef DOI cross-check (full author list). Không DB write. Không ACCEPT/REJECT/REVOKE.  
**Phạm vi:** TS. Phạm Đức Long (×3 IDs) + TS. Đỗ Thị Bắc (×5 IDs)  
**Tiếp nối từ Batch 4:** Scopus Preview server tiếp tục trả "Unable to display author profile" (server issue kéo dài từ Batch 3).

---

## Coverage tích lũy (sau Batch 5)

| Metric | Batch 1–4 | Batch 5 | Tích lũy |
|--------|-----------|---------|----------|
| GVs đã kiểm tra | 12 | 2 | **14/34** |
| IDs đã kiểm tra | 38 | 8 | **46/83** |
| IDs body accessible | 16 | 0 | 16/46 |
| IDs page title confirmed | 28 | 8 | 36/46 |
| IDs không tìm thấy | 3 | 0 | 3/46 |
| IDs có bằng chứng CORROBORATED | 5 | 3 | **8/46** |

---

## Nguồn ICTU-WEB

**URL:** `https://repository.ictu.edu.vn/huong-dan-gop-tai-khoan-scopus/`  
**Xác nhận:** Browser DOM extraction, 2026-10-27

---

## TS. Phạm Đức Long — `pdlong@ictu.edu.vn`

**ICTU-WEB claim:** 3 IDs, 6 pubs, primary `26637116200`

| Scopus ID | Role | Page Title | Body | CSV pubs | Name in title | Notes |
|-----------|------|-----------|------|----------|---------------|-------|
| 26637116200 | PRIMARY | CONFIRMED | UNABLE_TO_DISPLAY | 4 | "Long, Pham Duc" | **PUBLICATION_NAME_CORROBORATED** via CrossRef DOI; 4 pubs 2009–2024 |
| 57197579769 | SECONDARY | CONFIRMED | UNABLE_TO_DISPLAY | 1 | "Pham, Duc Long" | Inverted name tokenization; 1 pub |
| 58805722900 | SECONDARY | CONFIRMED | UNABLE_TO_DISPLAY | 1 | "Long, Pham Duc" | Same form as primary; 1 pub 2009 (IEEE CISP) |

**CrossRef DOI 10.1007/978-3-031-50818-9_35 (Springer 2024):**  
Authors (full): **Pham Duc Long** (pos. 1/1)  
Single-author paper. Publisher: Springer LNCS. **MATCHES** ID 26637116200. → PUBLICATION_NAME_CORROBORATED  
*(No affiliation in CrossRef metadata. Name-only.)*

**CrossRef DOI 10.1109/CISP.2009.5303557 (IEEE 2009):**  
Authors (full): Nguyen Tuan Minh · Pham Thuong Cat · **Pham Duc Long** (pos. 3/3)  
**MATCHES** name form for Phạm Đức Long. → PUBLICATION_NAME_CORROBORATED (secondary confirmation)

**Domain:** Image processing, cellular neural networks, AI in agriculture — coherent domain.

**Discrepancy — ICTU-WEB 6 pubs vs CSV 6:**  
CSV: 4+1+1 = 6 unique EIDs. ICTU-WEB: 6. **No discrepancy.** Count matches exactly.

**Cross-ID EID duplicates:** 0

---

## TS. Đỗ Thị Bắc — `dtbac@ictu.edu.vn`

**ICTU-WEB claim:** 5 IDs, 11 pubs, primary `59526508700`

| Scopus ID | Role | Page Title | Body | CSV pubs | Name in title | Notes |
|-----------|------|-----------|------|----------|---------------|-------|
| 59526508700 | PRIMARY | CONFIRMED | UNABLE_TO_DISPLAY | 8 | "Do, Thi Bac" | **PUBLICATION_NAME_CORROBORATED** via CrossRef DOI; 8 pubs |
| 57819997900 | SECONDARY | CONFIRMED | UNABLE_TO_DISPLAY | 3 | "Do, Bac Thi" | Inverted tokenization; 3 pubs |
| 59663496400 | SECONDARY | CONFIRMED | UNABLE_TO_DISPLAY | 1 | "Bac, Do Thi" | Family=Bac form; 1 pub 2023 |
| 59159284800 | SECONDARY | CONFIRMED | UNABLE_TO_DISPLAY | 1 | "do Thi, Bac" | Unusual lowercase "do"; 1 pub |
| 57899449200 | SECONDARY | CONFIRMED | UNABLE_TO_DISPLAY | 1 | "ThiBac, Do" | **PUBLICATION_NAME_CORROBORATED** — name concatenated as "ThiBac" |

**Name variants observed:** "Do, Thi Bac" / "Do, Bac Thi" / "Bac, Do Thi" / "do Thi, Bac" / "ThiBac, Do" / "Thi-Bac Do" / "Bac Thi Do" — **7 forms** for same name Đỗ Thị Bắc. Highest count in this audit.

**CrossRef DOI 10.11591/eei.v14i3.9064 (IAES 2025):**  
Authors (full, 5 tác giả): May Thu Duong · Alexander A. Moldovyan · Nikolay A. Moldovyan · Minh Hieu Nguyen · **Bac Thi Do** (pos. 5/5)  
**MATCHES** ID 59526508700. → PUBLICATION_NAME_CORROBORATED  
*(Authors include Russian mathematicians — collaboration on non-commutative algebra.)*

**CrossRef DOI 10.1007/s00542-026-06031-2 (Springer 2026):**  
Authors (full, 2 tác giả): **Thi-Bac Do** (pos. 1/2) · Quang-Huy Tran (ID 57208579583)  
**MATCHES** ID 57899449200 (title: "ThiBac, Do"). → PUBLICATION_NAME_CORROBORATED  
*Note: Co-author "Quang-Huy Tran" (ID 57208579583) is NOT in the 9-GV Batch 1–4 list — no confirmed ICTU identity.*

**Discrepancy — ICTU-WEB 11 pubs vs CSV 14:**  
CSV: 8+3+1+1+1 = 14 unique EIDs. ICTU-WEB: 11. Chênh lệch +3 — secondary IDs không được đếm bởi ICTU-WEB. Pattern nhất quán với tất cả các Batch trước.

**Cross-ID EID duplicates:** 0

---

## Cross-GV Coauthorship (Batch 5)

**PDL cross-GV:** Không có cross-GV EIDs với các GVs Batch 1–4 trong CSV này.  
**DTB cross-GV:** Không có cross-GV EIDs với các GVs Batch 1–4 trong CSV này.  
**PDL × DTB:** 0 EIDs.

*Lưu ý: CSV là personal export của QH (Sep 2026). PDL và DTB có thể đồng tác giả với GVs khác không có trong CSV này. Thiếu thông tin không có nghĩa là không đồng tác giả.*

---

## DOI Cross-Check Summary

| DOI | GV | ID | Full author count | Match | Result |
|-----|----|----|---|---|---|
| 10.1007/978-3-031-50818-9_35 | PDL | 26637116200 | 1 | #1 "Pham Duc Long" | PUBLICATION_NAME_CORROBORATED |
| 10.1109/CISP.2009.5303557 | PDL | 58805722900 | 3 | #3 "Pham Duc Long" | PUBLICATION_NAME_CORROBORATED |
| 10.11591/eei.v14i3.9064 | DTB | 59526508700 | 5 | #5 "Bac Thi Do" | PUBLICATION_NAME_CORROBORATED |
| 10.1007/s00542-026-06031-2 | DTB | 57899449200 | 2 | #1 "Thi-Bac Do" | PUBLICATION_NAME_CORROBORATED |

---

## Findings Summary

| Finding | GV | Severity | Type |
|---------|-----|---------|------|
| 7 name variants cho Đỗ Thị Bắc — nhiều nhất trong audit này | Đỗ Thị Bắc | LOW | NAME_TOKENIZATION_VARIANT (7 forms) |
| ICTU-WEB 11 vs CSV 14 pubs | Đỗ Thị Bắc | LOW | COVERAGE_GAP — secondaries không đếm |
| ICTU-WEB 6 vs CSV 6 pubs | Phạm Đức Long | INFO | COUNT_MATCH — không chênh lệch |
| Tất cả 8 IDs UNABLE_TO_DISPLAY | Cả 2 | OBSERVATION | SCOPUS_SERVER_ISSUE (tiếp tục từ Batch 3) |
| Co-author "Quang-Huy Tran" (57208579583) không trong audit list | Đỗ Thị Bắc | INFO | UNRESOLVED_COAUTHOR — không thể xác nhận ICTU identity |

---

## Deliverables

| File | Rows | Description |
|------|------|-------------|
| `batch5_id_evidence.csv` | 8 | Per-ID: browser + CSV + CrossRef evidence |
| `batch5_publication_evidence.csv` | 20 | 6 PDL + 14 DTB unique EIDs, 0 intra-GV dups (strict UTF-8) |
| `batch5_browser_evidence.json` | — | Full structured evidence |
| `batch5_summary.md` | — | This file |

---

*Tạo bởi Claude Sonnet 4.6 ngày 2026-10-27 — read-only, không DB write.*
