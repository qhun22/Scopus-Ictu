# Gate D.2 Batch 3 — Summary

**Ngày:** 2026-10-27  
**Phương pháp:** Read-only. Browser mở thực tế. CSV scan. CrossRef DOI cross-check. Không DB write. Không ACCEPT/REJECT/REVOKE.  
**Phạm vi:** TS. Lê Hùng Linh (×3 IDs) + TS. Nguyễn Văn Tảo (×3 IDs)

---

## Coverage tích lũy (sau Batch 3)

| Metric | Batch 1+2 | Batch 3 | Tích lũy |
|--------|-----------|---------|----------|
| GVs đã kiểm tra | 8 | 2 | **10/34** |
| IDs đã kiểm tra | 26 | 6 | **32/83** |
| IDs body accessible | 16 | 0 | 16/32 |
| IDs page title confirmed | 16 | 6 | 22/32 |
| IDs không tìm thấy | 3 | 0 | 3/32 |
| IDs có bằng chứng E5 | 1 | 2 | **3/32** |

_Batch 3 có đặc điểm: tất cả 6 IDs đều trả "Unable to display" body — Scopus Preview server issue ngày 2026-10-27. Page title xác nhận tên cho cả 6._

---

## Nguồn ICTU-WEB

**URL:** `https://repository.ictu.edu.vn/huong-dan-gop-tai-khoan-scopus/`  
**Phương pháp xác nhận:** Browser live DOM extraction, 2026-10-27  
**Cấu trúc bảng:** 35 hàng (1 header + 34 data), xác nhận cả LHL lẫn NVT đều có trong bảng

---

## TS. Lê Hùng Linh — `lhlinh@ictu.edu.vn`

**ICTU-WEB claim:** 3 IDs, 12 pubs, primary `56548128100`

| Scopus ID | Role | Page Title | Body | CSV pubs | Name in title | Notes |
|-----------|------|-----------|------|----------|---------------|-------|
| 56548128100 | PRIMARY | CONFIRMED | UNABLE_TO_DISPLAY | 13 | "Le, Hung Linh" | Main profile; 13 pubs spanning 2010–2026 |
| 58830932700 | SECONDARY | CONFIRMED | UNABLE_TO_DISPLAY | 1 | "Linh, Le Hung" | **E5 via CrossRef** — DOI 10.1109/ICCA.2010.5524407 confirms "Le Hung, Linh" 2010 motor speed |
| 57200439355 | SECONDARY | CONFIRMED | UNABLE_TO_DISPLAY | 1 | "Le, Linh" | 1 pub 2018 (neural network mobile robot); name is shortened form |

**Discrepancy — ICTU-WEB 12 pubs vs CSV 15:**  
ICTU-WEB lists 12 pubs for primary ID. CSV shows 13 (primary) + 1 (58830932700) + 1 (57200439355) = **15 unique EIDs**.  
Difference of +3: secondary IDs not counted by ICTU-WEB. Consistent with Batch 1 pattern (QXT: +3 same reason).  
**This discrepancy does NOT contradict identity — it is a coverage difference between ICTU Repository and Scopus.**

**Cross-ID EID duplicates:** 0 (confirmed by full CSV scan)

---

## TS. Nguyễn Văn Tảo — `nvtao@ictu.edu.vn`

**ICTU-WEB claim:** 3 IDs, 16 pubs, primary `57192958573`

| Scopus ID | Role | Page Title | Body | CSV pubs | Name in title | Notes |
|-----------|------|-----------|------|----------|---------------|-------|
| 57192958573 | PRIMARY | CONFIRMED | UNABLE_TO_DISPLAY | 5 | "van Tao, Nguyen" | Lowercase "van" — Vietnamese name handling variant |
| 56967513900 | SECONDARY | CONFIRMED | UNABLE_TO_DISPLAY | 7 | "Nguyen, Van Tao / Nguyen, Van-Tao" | **DOI anomaly flagged** (see below) |
| 57221224211 | SECONDARY | CONFIRMED | UNABLE_TO_DISPLAY | 2 | "Nguyen, Tao V. / Nguyen, Tao Van" | **E5 via CrossRef** — DOI 10.3390/fi17080350 confirms ICTU affiliation |

**DOI Anomaly — 56967513900:**  
DOI `10.1109/MNET.010.2100509` appears in CSV for ID 56967513900. However, CrossRef confirms this paper's authors are "Nguyen, Van-Linh" et al. from CCU, Taiwan — **not an ICTU author named Van Tao**. Two possible explanations:  
(a) Scopus CSV metadata error — wrong ID attributed to this paper in export  
(b) Scopus disambiguation issue — two Nguyen Van * profiles conflated  
**This DOI is flagged. Human reviewer must verify whether this pub truly belongs to NVT (56967513900).**  
The remaining 6 pubs for this ID have not been cross-checked via publisher.

**Discrepancy — ICTU-WEB 16 pubs vs CSV 14:**  
ICTU-WEB lists 16 pubs. CSV shows 5+7+2 = **14 unique EIDs**.  
CSV is QH's personal Scopus export (see FINDING-008 context). −2 pubs missing from CSV is consistent with papers NVT authored without QH as co-author.

**Cross-ID EID duplicates:** 0 (confirmed by full CSV scan)

---

## DOI Cross-Check Summary

| DOI | GV | Scopus ID | CrossRef Result | Verdict |
|-----|-----|-----------|----------------|---------|
| 10.1109/ICCA.2010.5524407 | LHL | 58830932700 | "Le Hung, Linh" — motor speed 2010 — **MATCHES** | E5 CONFIRMED |
| 10.1109/MNET.010.2100509 | NVT | 56967513900 | "Nguyen, Van-Linh" from CCU Taiwan — **NO MATCH** | ANOMALY — FLAGGED |
| 10.3390/fi17080350 | NVT | 57221224211 | "Nguyen, Tao V." from ICTU — **MATCHES** | E5 CONFIRMED |

---

## Findings Summary

| Finding | GV | Severity | Type |
|---------|-----|---------|------|
| ICTU-WEB 12 vs CSV 15 pubs | Lê Hùng Linh | LOW | COVERAGE_GAP — secondary IDs not counted by ICTU-WEB |
| All 6 Scopus bodies "Unable to display" | Both | OBSERVATION | SCOPUS_SERVER_ISSUE — page titles still confirmed |
| DOI anomaly: 56967513900 — CrossRef Taiwan author | Nguyễn Văn Tảo | MEDIUM | DOI_ATTRIBUTION_ANOMALY — flagged for reviewer |
| ICTU-WEB 16 vs CSV 14 pubs | Nguyễn Văn Tảo | LOW | COVERAGE_GAP — CSV is personal export, not full Scopus |
| Name variant: 57192958573 "van Tao, Nguyen" (lowercase) | Nguyễn Văn Tảo | INFO | NAME_TOKENIZATION — expected Vietnamese name handling |

---

## Deliverables

| File | Rows | Description |
|------|------|-------------|
| `batch3_id_evidence.csv` | 6 | One row per ID; browser + CSV + CrossRef evidence |
| `batch3_publication_evidence.csv` | 29 | All pub rows per ID (15 LHL + 14 NVT, 0 intra-GV dups) |
| `batch3_browser_evidence.json` | — | Structured DOM + CrossRef evidence for 6 IDs + ICTU-WEB |
| `batch3_summary.md` | — | This file |

---

## Coverage Breakdown — Batch 3 + Cumulative

### Batch 3 per-GV

| GV | IDs | CSV pubs | Unique EIDs | Bodies accessible | DOI E5 confirmed |
|----|-----|----------|-------------|-------------------|-----------------|
| TS. Lê Hùng Linh | 3 | 15 | 15 | 0/3 (server error) | 1/3 (58830932700) |
| TS. Nguyễn Văn Tảo | 3 | 14 | 14 | 0/3 (server error) | 1/3 (57221224211) |

### Cumulative Gate D — all batches

| Batch | GVs | IDs checked | IDs accessible | IDs not found | E5 evidence |
|-------|-----|-------------|---------------|---------------|-------------|
| Batch 1 (QXT/DQA/PTN) | 3 | 7 (+3 prior) = 10 | 7 | 1 (58937710300) | 0 |
| Batch 2 (LMH/NHM) | 2 | 9 | 7 | 3 (LMH secondaries) | 1 (NHM DOI PLOS) |
| Batch 3 (LHL/NVT) | 2 | 6 | 0 body (server) / 6 title | 0 | 2 (LHL + NVT CrossRef) |
| **TOTAL** | **10/34** | **32/83** | **~23 accessible** | **4 not found** | **3 IDs** |

_Note: "accessible" means Scopus Preview body returned content (not error). 6 Batch 3 IDs are "BROWSER_OPENED" not "PROFILE_ACCESSIBLE" due to server issue._

---

*Tạo bởi Claude Sonnet 4.6 ngày 2026-10-27 — read-only, không DB write.*
