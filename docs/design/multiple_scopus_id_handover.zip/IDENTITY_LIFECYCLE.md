# Vòng đời Identity — Nhiều Scopus Author ID

> Trạng thái: **ANALYZED** · Ngày: 2026-10-27

---

## Sơ đồ trạng thái LecturerScopusIdentity

```
                 CandidateReviewService._accept()
                          │
              ┌───────────▼───────────┐
              │       CANDIDATE       │  (status default khi tạo)
              └───────────┬───────────┘
                          │ APPROVE (MappingReview)
              ┌───────────▼───────────┐
              │       APPROVED        │◄──── Partial unique index
              └───────┬───────────────┘      uq_identities_scopus_author_approved
                      │ REVOKE (API gap G02)
              ┌───────▼───────────────┐
              │       REVOKED         │
              └───────┬───────────────┘
                      │ REOPEN (API gap G03)
              ┌───────▼───────────────┐
              │     CANDIDATE         │  (returned to reviewable)
              └───────────────────────┘

              REJECTED (từ CandidateReview workflow, khác với identity status)
```

## Trạng thái LecturerScopusCandidate (khác với identity)

```
PENDING ──── ACCEPT ──► ACCEPTED
        └─── REJECT ──► REJECTED
        └─── SUPERSEDE ► SUPERSEDED (khi có generation run mới?)

ACCEPTED/REJECTED/SUPERSEDED ──► PENDING (REOPEN — API gap G03)
```

## 8 Kịch bản lifecycle

### Kịch bản A — Baseline (1 ID)
Giảng viên L1 có 1 Scopus Author A1. Reviewer ACCEPT.  
→ identity(L1,A1) = APPROVED. Không có bước tiếp theo bình thường.  
**Trạng thái:** ✅ Fully supported

---

### Kịch bản B — Thêm ID thứ hai (multi-ID chủ động)
ADMIN phát hiện L1 publish dưới ID A2 (tên khác). Generation tạo candidate(L1,A2). Reviewer ACCEPT với reason.  
→ identity(L1,A1) vẫn APPROVED + identity(L1,A2) = APPROVED mới.  
**Trạng thái:** ✅ Fully supported (test #38)

---

### Kịch bản C — Xung đột: Author A1 đề xuất cho 2 giảng viên
A1 được match với cả L1 (ORCID exact) lẫn L2 (tên similar). Reviewer ACCEPT (L1,A1) trước.  
→ identity(L1,A1) = APPROVED. Khi reviewer thử ACCEPT (L2,A1) → Case C blocked (ScopusAuthorAlreadyApprovedError).  
**Trạng thái:** ✅ Fully supported (test #39)

---

### Kịch bản D — REJECT nhầm, muốn REOPEN
Reviewer REJECT (L1,A2) nhầm. Muốn reopen để review lại.  
→ **GAP G03**: Không có REOPEN API. Phải đợi generation run mới.  
**Trạng thái:** ❌ API gap

---

### Kịch bản E — REVOKE một trong các APPROVED IDs
ADMIN phát hiện identity(L1,A2) nhầm. Muốn REVOKE A2 nhưng giữ A1.  
→ **GAP G02**: Không có REVOKE API. Can thiệp DB trực tiếp.  
**Trạng thái:** ❌ API gap (DB model hỗ trợ)

---

### Kịch bản F — Scopus External Merge (A1 + A2 → A1 master)
Scopus merge profile A1 và A2 thành A1. L1 đang có APPROVED cho cả hai.  
→ **GAP G04**: Hệ thống không detect external merge.  
- Publications của A2 trên Scopus nay thuộc A1.  
- identity(L1,A2) vẫn APPROVED nhưng không còn valid.  
- Cần REVOKE identity(L1,A2) + re-import publications.  
**Trạng thái:** ❌ Future work

---

### Kịch bản G — Giảng viên rời ICTU
Giảng viên nghỉ việc. User account của giảng viên bị deactivate.  
→ Identity vẫn APPROVED (không tự REVOKE). Publications vẫn visible.  
→ ADMIN cần REVOKE thủ công nếu muốn ẩn.  
**Trạng thái:** Partially handled (deactivate user, nhưng identity không auto-REVOKE)

---

### Kịch bản H — Generation run thứ N tạo lại candidate cho ID đã APPROVED
Sau khi identity(L1,A1) = APPROVED, generation run tiếp theo tạo candidate(L1,A1) mới.  
→ candidate(L1,A1) mới. Khi ACCEPT:  
- `_check_identity_conflicts()` Case D/idempotency check.  
- Nếu identity vẫn APPROVED → idempotent success.  
- Nếu identity đã REVOKED → `PreexistingIdentityConflictError` hoặc re-approve flow.  
**Trạng thái:** ✅ Idempotency handled; REVOKE path cần test

---

## Bảng trạng thái tóm tắt

| Kịch bản | Mô tả | Trạng thái |
|----------|-------|-----------|
| A | 1 ID baseline | ✅ |
| B | Thêm ID thứ 2 | ✅ |
| C | Author conflict | ✅ |
| D | REOPEN sau REJECT nhầm | ❌ Gap G03 |
| E | REVOKE 1 trong N IDs | ❌ Gap G02 |
| F | Scopus external merge | ❌ Gap G04 |
| G | Giảng viên rời ICTU | Partial |
| H | Re-generation sau APPROVED | ✅ (idempotent) |
