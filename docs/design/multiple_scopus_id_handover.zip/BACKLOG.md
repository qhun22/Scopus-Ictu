# Backlog — Nhiều Scopus Author ID

> Trạng thái: **TRIAGED** · Ngày: 2026-10-27  
> Thứ tự ưu tiên: P0 → P1 → P2 → P3

---

## P0 — Trong scope luận văn (cần để demo/acceptance)

### BL-01 Viết test T06 (SHARED_SCOPUS_AUTHOR D-2 trigger)
- **File:** `tests/integration/test_candidate_review_service.py`
- **Mô tả:** Tạo 2 candidates cho cùng Scopus Author từ 2 giảng viên khác nhau. ACCEPT một → verify trigger `SHARED_SCOPUS_AUTHOR` fire.
- **Effort:** S (1–2h)

### BL-02 Viết test T07 (Publication dedup qua N IDs)
- **File:** `tests/integration/test_candidate_review_service.py` hoặc `test_lecturer_scopus_projection.py`
- **Mô tả:** L1 có 2 APPROVED IDs cùng là author của 1 publication. Verify total=1 không phải 2.
- **Effort:** S (1–2h)

### BL-03 Viết test T08 (Idempotent ACCEPT tường minh)
- **File:** `tests/integration/test_candidate_review_service.py`
- **Mô tả:** Submit ACCEPT 2 lần cho cùng candidate+observation. Verify idempotent=True lần 2.
- **Effort:** XS (< 1h)

---

## P1 — Nên có trong luận văn nhưng không blocking

### BL-04 Viết test T09 (Concurrent race condition — SELECT FOR UPDATE)
- **Mô tả:** Dùng threading để submit 2 ACCEPT đồng thời. Verify chỉ 1 thành công.
- **Effort:** M (3–4h, cần setup concurrent test infrastructure)
- **Note:** Có thể document thay vì implement nếu không đủ thời gian

### BL-05 Document gap G02 (REVOKE API) trong luận văn
- **Mô tả:** Thêm phần "Hạn chế và hướng phát triển" — đề cập REVOKE endpoint chưa có.
- **Effort:** XS (30 phút viết)

### BL-06 Document gap G03 (REOPEN API) trong luận văn
- **Tương tự BL-05**

---

## P2 — Future work (sau luận văn)

### BL-07 Implement REVOKE identity endpoint
- `POST /api/v1/identities/{identity_id}/revoke`
- Pattern: copy từ candidate REJECT workflow
- **Effort:** M (2–3 ngày)

### BL-08 Implement REOPEN candidate endpoint
- `POST /api/v1/reviews/{candidate_id}/reopen`
- Phức tạp hơn REVOKE vì phải clear ACCEPTED state
- **Effort:** L (3–5 ngày)

### BL-09 Dashboard widget: giảng viên có nhiều Scopus IDs
- Aggregate query: `COUNT(*) WHERE approved_identity_count > 1`
- Thêm widget vào `Dashboard/index.tsx`
- **Effort:** S (1–2 ngày)

### BL-10 UI side-by-side comparison trong ApprovalQueue
- Khi `other_candidates_for_lecturer > 0`, hiện split panel
- **Effort:** M (3–5 ngày frontend)

---

## P3 — Nice-to-have

### BL-11 Scopus External Merge detection
- Background job poll Scopus API kiểm tra Author ID redirect
- Notify ADMIN khi phát hiện merge
- **Effort:** XL (integration với Scopus API, cần API key)

### BL-12 Tự động import publications khi ACCEPT ID mới
- Sau ACCEPT identity mới, trigger re-import publications của Scopus Author đó
- **Effort:** L (cần integration với import pipeline)

---

## Thứ tự triển khai đề xuất cho đồ án

1. BL-01 (T06) — viết test trước khi demo
2. BL-02 (T07) — critical cho tính đúng của dedup
3. BL-03 (T08) — dễ, nhanh
4. BL-05, BL-06 — viết document vào luận văn
5. BL-04 (T09) — nếu còn thời gian
