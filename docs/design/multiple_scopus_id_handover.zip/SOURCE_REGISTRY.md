# Source Registry — Hỗ trợ nghiệp vụ nhiều Scopus Author ID

> Trạng thái: **VERIFIED** · Ngày: 2026-10-27  
> Phạm vi: Tính năng một giảng viên ↔ nhiều Scopus Author ID (ICTU: 35 giảng viên có ≥ 2 ID)

---

## 1. Nguồn chính thức Scopus / Elsevier

| Mã | Tên nguồn | URL / Tham chiếu | Nội dung xác nhận |
|----|-----------|------------------|-------------------|
| SCP-01 | Scopus Author Profile Help | `https://service.elsevier.com/app/answers/detail/a_id/11212` | Một người có thể có nhiều Profile nếu tên viết theo nhiều cách khác nhau hoặc đăng ký ở nhiều cơ sở |
| SCP-02 | Author Profile Merger | `https://service.elsevier.com/app/answers/detail/a_id/11212/~/request-to-merge-author-profiles-in-scopus` | Scopus cung cấp công cụ merge; sau merge ID cũ vẫn redirect về ID mới |
| SCP-03 | Scopus Author ID FAQ | `https://www.scopus.com/freelookup/form/author.uri` | Mỗi Scopus Author ID là định danh duy nhất, bền vững |
| SCP-04 | Elsevier Author Feedback Wizard | Giao diện tự báo cáo trùng hồ sơ | Giảng viên có thể tự yêu cầu merge qua wizard |
| SCP-05 | Scopus Preview API | `https://api.elsevier.com/documentation/SCOPUSSearchAPI.wadl` | `dc:identifier` chứa `AUTHOR_ID:XXXXXXX` |

## 2. Nguồn dữ liệu mở / bổ trợ

| Mã | Nguồn | URL | Vai trò trong dự án |
|----|-------|-----|---------------------|
| OA-01 | OpenAlex Works API | `https://api.openalex.org/works?filter=authorships.author.id:…` | Tra cứu cross-reference DOI → Author |
| OA-02 | OpenAlex Authors API | `https://api.openalex.org/authors/A…` | Xác nhận ORCID → Scopus ID map |
| OA-03 | OpenAlex merge history | `ids.openalex` field | Phát hiện merged author ID |
| CR-01 | Crossref REST API | `https://api.crossref.org/works/{doi}` | Xác thực DOI, author affiliation |
| CR-02 | Crossref metadata | `author[].affiliation[]` | ICTU affiliation lookup |
| OR-01 | ORCID Public API | `https://pub.orcid.org/v3.0/{orcid}/works` | ORCID → Scopus Author ID map |

## 3. Nguồn nội bộ ICTU

| Mã | Nguồn | Nơi lưu trữ | Ghi chú |
|----|-------|-------------|---------|
| ICTU-01 | DS. Vũ Thị Quỳnh Anh | `SCOPUS_RAW_DIR` / CRAW | Author ID: `57223028088` |
| ICTU-02 | TS. Trương Thị Thu Hà | `SCOPUS_RAW_DIR` | Author ID: `57226012765` |
| ICTU-03 | TS. Đỗ Đình Cường | `SCOPUS_RAW_DIR` | Author IDs: `26423550300`, `60561601800` |
| ICTU-04 | ThS. Đinh Xuân Lâm | `SCOPUS_RAW_DIR` | Author ID: `59192485500` |
| ICTU-05 | PGS.TS. Nguyễn Xuân Huy | `SCOPUS_RAW_DIR` | Author ID: xác nhận bổ sung |
| ICTU-06 | GS.TS. Lương Chi Mai | `SCOPUS_RAW_DIR` | Author ID: xác nhận bổ sung |

## 4. Nguồn kỹ thuật nội bộ (repository)

| File | Vai trò |
|------|---------|
| `backend/app/models/identity.py` | LecturerScopusIdentity, IdentityEvidence, MappingReview — constraint chính |
| `backend/app/models/candidate.py` | LecturerScopusCandidate, CandidateGenerationRun, Evidence, Review |
| `backend/app/services/candidate_review_service.py` | Logic ACCEPT/REJECT, _check_identity_conflicts (Cases A–E) |
| `backend/app/services/review_reason_policy.py` | D-2 policy: 3 trigger conditions |
| `backend/app/services/lecturer_scopus_projection.py` | _publication_set() DISTINCT, get_approved_identity_summaries() |
| `backend/app/services/matching/candidate_generator.py` | 7 rules RULE_EXACT_N0 → RULE_N2_HYPHEN |
| `backend/tests/integration/test_candidate_review_service.py` | Tests #38, #39 xác nhận multi-ID |

## 5. Ấn phẩm làm bằng chứng (Evidence Pack)

| Mã | DOI | Giảng viên | Ghi chú |
|----|-----|------------|---------|
| PUB-01 | `10.1007/978-3-031-50818-9_37` | TS. Đỗ Đình Cường | ORCID `0009-0004-7250-6710`, Springer 2024 |
| PUB-02 | `10.1007/978-3-031-80943-9_19` | ThS. Đinh Xuân Lâm | IAST/ICTU, tác giả thứ 3, Springer |

---
*File này chỉ mô tả cấu trúc nguồn; không chứa dữ liệu thực Scopus/ICTU.*
