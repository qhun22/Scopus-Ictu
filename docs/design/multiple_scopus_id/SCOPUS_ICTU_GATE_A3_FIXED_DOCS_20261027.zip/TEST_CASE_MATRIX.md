# Ma trận test case — Nhiều Scopus Author ID

> Trạng thái: **SPECIFIED** · Ngày: 2026-10-27  
> Phạm vi: T01–T10 — unit + integration, không ghi DB 5432, không auto-ACCEPT

---

## T01 — Giảng viên ACCEPT ID thứ nhất (baseline)

**Mô tả:** Giảng viên L1 chưa có APPROVED identity nào. Candidate (L1, A1) được ACCEPT.  
**Pre-condition:** candidate(L1,A1) status=PENDING, không có identity APPROVED nào cho L1 hay A1.  
**Inputs:** AcceptCandidateCommand(candidate_id, observation_id, version, reviewer_id)  
**Expected:**
- `AcceptResult.candidate_status == "ACCEPTED"`
- `AcceptResult.idempotent == False`
- `LecturerScopusIdentity` mới với status=APPROVED
- D-2 triggers: `[]` nếu có PUBLICATION evidence, `["NAME_EVIDENCE_ONLY"]` nếu chỉ có NAME
- Không exception

**Test file:** `tests/integration/test_candidate_review_service.py` — test #38 (partial)  
**Status:** ✅ Đã có test tương đương

---

## T02 — Giảng viên ACCEPT ID thứ hai (multi-ID happy path)

**Mô tả:** Giảng viên L1 đã có APPROVED identity (L1,A1). Reviewer ACCEPT (L1,A2).  
**Pre-condition:** identity(L1,A1) status=APPROVED; candidate(L1,A2) status=PENDING.  
**Inputs:** AcceptCandidateCommand(L1,A2, reason="Tên khác nhau do viết tắt")  
**Expected:**
- Case B: allowed (không raise exception)
- `AcceptResult.candidate_status == "ACCEPTED"`
- `get_approved_identity_summaries(L1)` trả 2 phần tử
- `_publication_set(L1)` dedup publications qua cả A1 lẫn A2
- D-2 trigger `MULTIPLE_CANDIDATES_FOR_LECTURER` → reason required ✓

**Test file:** `tests/integration/test_candidate_review_service.py` test #38  
**Status:** ✅ Đã có

---

## T03 — BLOCKED: Scopus Author đã APPROVED cho giảng viên khác (Case C)

**Mô tả:** A1 đã APPROVED cho L1. Reviewer thử ACCEPT (L2,A1).  
**Pre-condition:** identity(L1,A1) status=APPROVED; candidate(L2,A1) status=PENDING.  
**Expected:**
- `ScopusAuthorAlreadyApprovedError` raised
- HTTP 409 tại endpoint
- Không tạo identity mới
- identity(L1,A1) không bị ảnh hưởng

**Test file:** `tests/integration/test_candidate_review_service.py` test #39  
**Status:** ✅ Đã có

---

## T04 — D-2: ACCEPT với NAME_EVIDENCE_ONLY không có reason → fail

**Mô tả:** Candidate chỉ có NAME evidence (không có PUBLICATION). Reviewer ACCEPT mà không có reason.  
**Pre-condition:** observation evidence chỉ chứa kind=NAME.  
**Inputs:** AcceptCandidateCommand(reason=None)  
**Expected:**
- `ReviewReasonRequiredForWeakEvidenceError(triggers=("NAME_EVIDENCE_ONLY",))`
- HTTP 422 với triggers trong response body
- Không có LecturerScopusIdentity được tạo

**Status:** ✅ Đã có test tương đương trong policy tests

---

## T05 — D-2: ACCEPT với NAME+PUBLICATION và reason=None → pass

**Mô tả:** Candidate có cả NAME lẫn PUBLICATION evidence. Reviewer ACCEPT mà không có reason.  
**Pre-condition:** observation evidence chứa kind=NAME và kind=PUBLICATION.  
**Inputs:** AcceptCandidateCommand(reason=None)  
**Expected:**
- Không raise `ReviewReasonRequiredForWeakEvidenceError`
- `AcceptResult` thành công
- `AcceptResult.publication_evidence_promoted >= 1`

**Status:** ✅ Kiểm tra qua `review_reason_policy.py:64` — PUBLICATION present → trigger không fire

---

## T06 — D-2: SHARED_SCOPUS_AUTHOR trigger

**Mô tả:** Scopus Author A1 đang là PENDING candidate cho cả L1 lẫn L2. Reviewer ACCEPT (L1,A1).  
**Pre-condition:** candidate(L1,A1) PENDING, candidate(L2,A1) PENDING.  
**Inputs:** AcceptCandidateCommand(reason="Đây là giảng viên L1 vì ORCID khớp")  
**Expected:**
- `SHARED_SCOPUS_AUTHOR` trong triggers
- AcceptResult thành công vì reason được cung cấp
- Candidate (L2,A1) vẫn PENDING nhưng bước tiếp theo sẽ bị Case C block

**Test file:** `tests/integration/test_review_reason_policy.py:129` — `test_shared_scopus_author_requires_reason_even_with_publication_evidence`  
**Status:** ✅ Đã có test tại dòng 129 (xác minh trigger `SHARED_SCOPUS_AUTHOR` fire và require reason)

---

## T07 — Publication dedup qua nhiều APPROVED IDs

**Mô tả:** L1 có 2 APPROVED IDs (A1, A2). Cả hai đồng tác giả cùng publication P1. Khi get_lecturer_publications(L1), P1 chỉ xuất hiện 1 lần.  
**Pre-condition:** PublicationAuthor(P1, A1) và PublicationAuthor(P1, A2) đều tồn tại.  
**Expected:**
- `get_lecturer_publications(L1)` total = 1 (không phải 2)
- `items[0].linked_author_orders` chứa cả hai author_order
- `approved_identity_count == 2`

**Status:** 🔶 Test T07 chưa có — cần viết; dedup logic đã có tại `lecturer_scopus_projection.py:305–330`

---

## T08 — Idempotent ACCEPT (cùng observation submit 2 lần)

**Mô tả:** Reviewer submit ACCEPT cùng candidate + observation 2 lần (race condition hoặc retry).  
**Pre-condition:** Sau khi ACCEPT lần 1 thành công.  
**Inputs:** AcceptCandidateCommand giống hệt lần 1  
**Expected:**
- `AcceptResult.idempotent == True`
- Không tạo thêm identity
- Trả `resulting_identity_id` giống lần 1
- Không exception

**Test file:** `tests/integration/test_candidate_review_service.py:582` — `test_accept_retry_is_idempotent`  
**Status:** ✅ Đã có test tại dòng 582 (xác minh `idempotent=True` khi submit lần 2)

---

## T09 — Concurrent ACCEPT: race condition SELECT FOR UPDATE

**Mô tả:** Hai reviewer đồng thời submit ACCEPT cho cùng candidate (L1, A1).  
**Pre-condition:** Không có identity APPROVED nào.  
**Expected:**
- Một trong hai thành công (AcceptResult)
- Người kia nhận `CandidateAlreadyDecidedError` hoặc DB unique constraint error
- Không có 2 APPROVED identities được tạo

**Test files:** `tests/integration/test_candidate_review_service.py`:
- Dòng 1403: `test_concurrent_accept_same_author_has_one_winner`
- Dòng 1457: `test_concurrent_accept_same_candidate_has_no_duplicates`
- Dòng 1502: `test_concurrent_opposite_decisions_have_one_terminal_winner`  
**Status:** ✅ Đã có 3 concurrent tests; SELECT FOR UPDATE tại `candidate_review_service.py:287–300`

---

## T10 — REVOKE identity + REOPEN lifecycle (MappingReview)

**Mô tả:** Identity(L1,A1) status=APPROVED → REVOKE → status=REVOKED → REOPEN → status=CANDIDATE.  
**Pre-condition:** `MappingReview.action` constraints tại `identity.py:281–306`.  
**Note:** Không có POST REOPEN endpoint trong hệ thống hiện tại. `mapping_reviews` có CHECK constraint cho phép REOPEN. Đây là **GAP P2** — lifecycle DB hỗ trợ nhưng API chưa expose.  
**Expected nếu được implement:**
- REVOKE: from_status=APPROVED, to_status=REVOKED, compensates_review_id=NOT NULL
- REOPEN: from_status=REVOKED, to_status=CANDIDATE, compensates_review_id=NOT NULL
- Sau REOPEN: identity có thể được APPROVE lại qua CandidateReview workflow

**Note:** T10 liên quan đến **GAP G02** (REVOKE) và **GAP G03** (REOPEN), không phải G04 (External Merge).  
**Status:** ❌ API endpoint chưa có — xem GAP_ANALYSIS.md#G02 và #G03

---

## Tóm tắt trạng thái

| Test | Mô tả ngắn | Trạng thái |
|------|-----------|-----------|
| T01 | Multi-ID baseline (ID 1) | ✅ Đã có |
| T02 | Multi-ID happy path (ID 2) | ✅ Đã có |
| T03 | Case C blocked | ✅ Đã có |
| T04 | D-2 NAME_ONLY no reason | ✅ Đã có |
| T05 | D-2 bypass khi có PUBLICATION | ✅ Đã có |
| T06 | D-2 SHARED_SCOPUS_AUTHOR | ✅ Đã có (`test_review_reason_policy.py:129`) |
| T07 | Publication dedup N IDs | 🔶 Cần viết |
| T08 | Idempotent ACCEPT | ✅ Đã có (`test_candidate_review_service.py:582`) |
| T09 | Concurrent race condition | ✅ Đã có (3 tests tại dòng 1403, 1457, 1502) |
| T10 | REVOKE/REOPEN lifecycle | ❌ API gap (G02, G03) |

**8/10 đã có** · **1/10 cần viết (T07)** · **1/10 blocked bởi API gap (T10)**
